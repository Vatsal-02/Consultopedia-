const sign_in_btn = document.querySelector("#sign-in-btn");
const dc_signup = document.querySelector("#dc-signup");
const pt_signup = document.querySelector("#pt-signup");
const ph_signup = document.querySelector("#ph-signup");
const container = document.querySelector(".container");

dc_signup.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});
pt_signup.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});
ph_signup.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});
